"""Django admin code for iscedxreports Django app."""
