"""
Models for the iscedxreports django app.
"""
